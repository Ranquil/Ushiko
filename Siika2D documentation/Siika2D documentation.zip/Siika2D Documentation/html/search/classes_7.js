var searchData=
[
  ['memorymanager',['MemoryManager',['../classcore_1_1_memory_manager.html',1,'core']]]
];
