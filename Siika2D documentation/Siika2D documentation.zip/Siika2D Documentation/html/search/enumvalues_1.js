var searchData=
[
  ['blue',['BLUE',['../namespacegraphics.html#a5acd35de041bd015ed25531e0fae2267a3761439984b0ca3eef1cbc26f0e7f87b',1,'graphics']]]
];
