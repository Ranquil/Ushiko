var searchData=
[
  ['x',['x',['../structcore_1_1saved__state.html#a6c625536ba2ab5f2444146f51977db89',1,'core::saved_state']]]
];
