var searchData=
[
  ['buffer',['buffer',['../structgraphics_1_1_sprite_manager_1_1sprites__buffer.html#a6508f1fb8d041dd1c826228bf810af7a',1,'graphics::SpriteManager::sprites_buffer']]]
];
