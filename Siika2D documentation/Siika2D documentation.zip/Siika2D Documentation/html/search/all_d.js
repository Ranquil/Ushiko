var searchData=
[
  ['operator_20delete',['operator delete',['../_memory_manager_8h.html#a3d97a7e2a0208075b4b37328c96ed390',1,'MemoryManager.h']]],
  ['operator_20delete_5b_5d',['operator delete[]',['../_memory_manager_8h.html#a1d8b2d6f17242ae0d182b0f7a98ba54f',1,'MemoryManager.h']]],
  ['operator_20new',['operator new',['../_memory_manager_8h.html#a82b4fcc5e4cfba2e146c56604a283344',1,'operator new(size_t size, const char *file, int line):&#160;MemoryManager.h'],['../_memory_manager_8h.html#a205ed048fdf5259c2e8e0cb60ee8f719',1,'operator new(size_t size):&#160;MemoryManager.h']]],
  ['operator_20new_5b_5d',['operator new[]',['../_memory_manager_8h.html#ac6a058e9defc8cd61985fa21887b59c4',1,'MemoryManager.h']]],
  ['operator_3d',['operator=',['../classcore_1_1_siika2_d.html#a7439e7fe097590d462d71e60d65c4d88',1,'core::Siika2D::operator=()'],['../classmisc_1_1_input.html#ac23e22a9bfd9f4c7e0c5317cbc04d7cb',1,'misc::Input::operator=()']]],
  ['operator_3d_3d',['operator==',['../classmisc_1_1_timer.html#a1b3f3c9dd038acd8d0b928a149e1953c',1,'misc::Timer']]]
];
