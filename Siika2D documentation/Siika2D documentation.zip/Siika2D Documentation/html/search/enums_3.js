var searchData=
[
  ['zoom',['ZOOM',['../namespacegraphics.html#a60ef003bf24ef2bd3331a743022da9ca',1,'graphics']]]
];
