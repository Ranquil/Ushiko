var searchData=
[
  ['microseconds',['MICROSECONDS',['../_timer_8h.html#ac8351ea77ae6a8faecc48c4a3766074fac9db1eab6da2865d20c916504baedc90',1,'Timer.h']]],
  ['milliseconds',['MILLISECONDS',['../_timer_8h.html#ac8351ea77ae6a8faecc48c4a3766074fa1043c5211bc8c40b382a93bd238c9131',1,'Timer.h']]]
];
