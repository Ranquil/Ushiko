var classgraphics_1_1_text_manager =
[
    [ "TextManager", "classgraphics_1_1_text_manager.html#ad9cfa98be55082022db42864e3c4b53a", null ],
    [ "~TextManager", "classgraphics_1_1_text_manager.html#a9176b8e0ebb67704649e5f7869b36317", null ],
    [ "createText", "classgraphics_1_1_text_manager.html#a1c4c160cd098a638ab46dc0e2f06dba8", null ],
    [ "drawTexts", "classgraphics_1_1_text_manager.html#a604db5cd05f5b09e7b626b5cd80abb8d", null ],
    [ "core::Siika2D", "classgraphics_1_1_text_manager.html#a7390b588209f3ddff65e7bec9eeed9be", null ]
];