var classgraphics_1_1_text =
[
    [ "Text", "classgraphics_1_1_text.html#a2649fbf4080d92745c61567267167d8f", null ],
    [ "~Text", "classgraphics_1_1_text.html#a2d49e5c280e205125b149f7777ae30c7", null ],
    [ "draw", "classgraphics_1_1_text.html#a84cd9e9e564326bd3d70864aa549d757", null ],
    [ "getColor", "classgraphics_1_1_text.html#a9001efab08bd0adbb6d1f8bde1ce577a", null ],
    [ "setColor", "classgraphics_1_1_text.html#a60ed7c4137d0389255e009a4b2bc7223", null ],
    [ "setFont", "classgraphics_1_1_text.html#a8cadfddca675317dff9ee4507e540a83", null ],
    [ "setFontSize", "classgraphics_1_1_text.html#a7f00c66c266a4380447731c1f9baaf50", null ],
    [ "setPosition", "classgraphics_1_1_text.html#afb53fea409321160c5bf8ef3a075ec3d", null ],
    [ "setText", "classgraphics_1_1_text.html#ab2d8c95b3d746ae3e8c0fba8318743c9", null ],
    [ "TextManager", "classgraphics_1_1_text.html#a72b63892b4338435846d7928babc8219", null ],
    [ "isInitialized", "classgraphics_1_1_text.html#aea40397415ee3f01e3a9bbcabfe768c6", null ]
];