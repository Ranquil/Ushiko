var structgraphics_1_1_sprite_manager_1_1sprites__buffer =
[
    [ "buffer", "structgraphics_1_1_sprite_manager_1_1sprites__buffer.html#a6508f1fb8d041dd1c826228bf810af7a", null ],
    [ "sprites", "structgraphics_1_1_sprite_manager_1_1sprites__buffer.html#ab2a50cdac20496b63abf022c7c54a685", null ]
];