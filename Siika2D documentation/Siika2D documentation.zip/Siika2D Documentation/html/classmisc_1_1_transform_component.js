var classmisc_1_1_transform_component =
[
    [ "TransformComponent", "classmisc_1_1_transform_component.html#ace1cf2d7d2a7468e9cb3eb0ce382f446", null ],
    [ "~TransformComponent", "classmisc_1_1_transform_component.html#a37d5d34a3695eafc8b8cbf37905e756f", null ],
    [ "getPosition", "classmisc_1_1_transform_component.html#a9b01146bcbd644b9ccb732ab41d959b2", null ],
    [ "getRotation", "classmisc_1_1_transform_component.html#a3811001fffdd78c71b4e7c836ef6e91c", null ],
    [ "move", "classmisc_1_1_transform_component.html#a26961936cb63b3b5a05991ecdcba3365", null ],
    [ "rotate", "classmisc_1_1_transform_component.html#a7141232cbbc4045aa70d46ce8477c87c", null ],
    [ "setPosition", "classmisc_1_1_transform_component.html#a11a1fe031193393a55904f9ebeb2d61b", null ],
    [ "setRotation", "classmisc_1_1_transform_component.html#a73cf09c04440f03362cd35cb2d8a3ecb", null ]
];