var classmisc_1_1_sprite_component =
[
    [ "SpriteComponent", "classmisc_1_1_sprite_component.html#a369943958b2c17f89746284534fca2a8", null ],
    [ "~SpriteComponent", "classmisc_1_1_sprite_component.html#a5315526604a8d5fe5b8b5d7cb46c382f", null ],
    [ "getSprite", "classmisc_1_1_sprite_component.html#ad86b6a003b804a48a0d398050964739e", null ]
];