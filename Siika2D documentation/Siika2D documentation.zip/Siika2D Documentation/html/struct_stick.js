var struct_stick =
[
    [ "_pointingVector", "struct_stick.html#abd0c2c1ea2e18b2578647cdb1c620e9f", null ],
    [ "_rotation", "struct_stick.html#a3890b38c461936dab99f78153fcc8219", null ]
];