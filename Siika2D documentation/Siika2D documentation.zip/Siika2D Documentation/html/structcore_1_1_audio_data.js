var structcore_1_1_audio_data =
[
    [ "fileDescriptor", "structcore_1_1_audio_data.html#a8775f8841a9a9d9ee6d5b57bb2d3d619", null ],
    [ "length", "structcore_1_1_audio_data.html#a46a45579b44f283572e5e2f9f871de4a", null ],
    [ "start", "structcore_1_1_audio_data.html#a9cb087c8a8beec2a4a4db27b6429b6a1", null ]
];