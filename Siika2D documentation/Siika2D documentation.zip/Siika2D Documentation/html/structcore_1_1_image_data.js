var structcore_1_1_image_data =
[
    [ "data", "structcore_1_1_image_data.html#af711282db8689c1981370c639dcc608e", null ],
    [ "height", "structcore_1_1_image_data.html#ac3f456a061449bbcfadfd1dccabe7f22", null ],
    [ "width", "structcore_1_1_image_data.html#a84d8fa4f50525658a9bda14c45afdd9c", null ]
];